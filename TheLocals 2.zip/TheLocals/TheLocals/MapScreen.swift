//
//  MapScreen.swift
//  TheLocals
//
//  Created by Jesus Luna on 12/10/19.
//  Copyright © 2019 Jesus Luna. All rights reserved.
//

import Foundation
import UIKit

class MapScreen: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
