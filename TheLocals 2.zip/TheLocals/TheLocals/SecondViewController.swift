//
//  SecondViewController.swift
//  TheLocals
//
//  Created by Jesus Luna on 12/10/19.
//  Copyright © 2019 Jesus Luna. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    override func viewDidLoad() {
         super.viewDidLoad()

         // Do any additional setup after loading the view.
     }
     
    @IBAction func b1(_ sender: UIButton) {
        guard let numberString = sender.titleLabel?.text, let url = URL(string: "telprompt://\(numberString)") else{
                   return
               }
               
               UIApplication.shared.open(url)
    }
    
    @IBAction func b2(_ sender: UIButton) {
        guard let numberString = sender.titleLabel?.text, let url = URL(string: "telprompt://\(numberString)") else{
                   return
               }
               
               UIApplication.shared.open(url)
    }
    
    @IBAction func b3(_ sender: UIButton) {
        guard let numberString = sender.titleLabel?.text, let url = URL(string: "telprompt://\(numberString)") else{
                   return
               }
               
               UIApplication.shared.open(url)
    }
    
    @IBAction func but1(_ sender: UIButton) {
    UIApplication.shared.open(URL(string:"https://www.instagram.com/brfootball/?hl=en")!as URL, options: [:], completionHandler: nil)
    }
    @IBAction func but2(_ sender: UIButton) {
        UIApplication.shared.open(URL(string:"https://www.instagram.com/433/?hl=en")!as URL, options: [:], completionHandler: nil)
    }
    @IBAction func but3(_ sender: UIButton) {        UIApplication.shared.open(URL(string:"https://www.instagram.com/mrbeast/?hl=en")!as URL, options: [:], completionHandler: nil)
    }
  

 

    /*// MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
